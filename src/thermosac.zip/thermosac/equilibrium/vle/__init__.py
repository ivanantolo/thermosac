# -*- coding: utf-8 -*-
"""
Created on Wed Aug 23 21:47:07 2023

@author: Ivan
"""
